package assignment;

/**
 * @author Robin Fritz
 * @version 1.0
 */
public class Sort {
}
